$(document).ready(function(){

  //$('*').css('border', '4px solid red');

  $('.header').animate({opacity: '100'}, 10000);

  $('.link1').animate({opacity: '100', bottom: '100px'}, 300);

  $('.logo').animate({opacity: '100', bottom: '25px'}, 500);



});
